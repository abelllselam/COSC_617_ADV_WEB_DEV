const fighters = [
  {
    name: "Jon Jones",
    nickname: "Bones",
    wins: 27,
    losses: 1,
    height: 1.93,
    weightClass: "Heavyweight",
    location: "Albuquerque, NM",
  },
  {
    name: "Israel Adesanya",
    nickname: "The Last Stylebender",
    wins: 24,
    losses: 3,
    height: 1.93,
    weightClass: "Middleweight",
    location: "Auckland, New Zealand",
  },
  {
    name: "Kamaru Usman",
    nickname: "The Nigerian Nightmare",
    wins: 20,
    losses: 4,
    height: 1.83,
    weightClass: "Welterweight",
    location: "Dallas, TX",
  },
  {
    name: "Sean O'Malley",
    nickname: "Sugar",
    wins: 17,
    losses: 1,
    height: 1.8,
    weightClass: "Bantamweight",
    location: "Glendale, AZ",
  },
  {
    name: "Alex Volkanovski",
    nickname: "The Great",
    wins: 26,
    losses: 4,
    height: 1.68,
    weightClass: "Featherweight",
    location: "Wollongong, Australia",
  },
  {
    name: "Islam Makhachev",
    nickname: "N/A",
    wins: 25,
    losses: 1,
    height: 1.78,
    weightClass: "Lightweight",
    location: "Makhachkala, Russia",
  },
  {
    name: "Leon Edwards",
    nickname: "Rocky",
    wins: 21,
    losses: 3,
    height: 1.83,
    weightClass: "Welterweight",
    location: "Birmingham, England",
  },
  {
    name: "Charles Oliveira",
    nickname: "Do Bronx",
    wins: 34,
    losses: 9,
    height: 1.78,
    weightClass: "Lightweight",
    location: "São Paulo, Brazil",
  },
  {
    name: "Brandon Moreno",
    nickname: "The Assassin Baby",
    wins: 21,
    losses: 7,
    height: 1.7,
    weightClass: "Flyweight",
    location: "Tijuana, Mexico",
  },
  {
    name: "Jiri Prochazka",
    nickname: "Denisa",
    wins: 29,
    losses: 4,
    height: 1.93,
    weightClass: "Light Heavyweight",
    location: "Humpolec, Czech Republic",
  },
  {
    name: "Aljamain Sterling",
    nickname: "Funk Master",
    wins: 23,
    losses: 4,
    height: 1.7,
    weightClass: "Bantamweight",
    location: "Uniondale, NY",
  },
  {
    name: "Max Holloway",
    nickname: "Blessed",
    wins: 26,
    losses: 7,
    height: 1.8,
    weightClass: "Featherweight",
    location: "Waianae, HI",
  },
  {
    name: "Robert Whittaker",
    nickname: "The Reaper",
    wins: 24,
    losses: 7,
    height: 1.83,
    weightClass: "Middleweight",
    location: "Sydney, Australia",
  },
  {
    name: "Alexander Pantoja",
    nickname: "N/A",
    wins: 27,
    losses: 5,
    height: 1.65,
    weightClass: "Flyweight",
    location: "Rio de Janeiro, Brazil",
  },
  {
    name: "Merab Dvalishvili",
    nickname: "The Machine",
    wins: 17,
    losses: 4,
    height: 1.68,
    weightClass: "Bantamweight",
    location: "Tbilisi, Georgia",
  },
  {
    name: "Curtis Blaydes",
    nickname: "Razor",
    wins: 18,
    losses: 4,
    height: 1.93,
    weightClass: "Heavyweight",
    location: "Chicago, IL",
  },
  {
    name: "Tom Aspinall",
    nickname: "N/A",
    wins: 14,
    losses: 3,
    height: 1.96,
    weightClass: "Heavyweight",
    location: "Manchester, England",
  },
  {
    name: "Tai Tuivasa",
    nickname: "Bam Bam",
    wins: 14,
    losses: 7,
    height: 1.88,
    weightClass: "Heavyweight",
    location: "Sydney, Australia",
  },
  {
    name: "Glover Teixeira",
    nickname: "N/A",
    wins: 33,
    losses: 9,
    height: 1.88,
    weightClass: "Light Heavyweight",
    location: "Sobralia, Brazil",
  },
  {
    name: "Marvin Vettori",
    nickname: "The Italian Dream",
    wins: 19,
    losses: 7,
    height: 1.83,
    weightClass: "Middleweight",
    location: "Mezzocorona, Italy",
  },
];

module.exports = fighters;

const { buildSchema } = require("graphql");
const { graphqlHTTP } = require("express-graphql");

const express = require("express");

const app = express();

const schema = buildSchema(`
  type Fighter {
    name: String
    nickname: String
    wins: Int
    losses: Int
    height: Float
    weightClass: String
    location: String
  }

  type Query {
    getFighterByName(name: String!): Fighter
    getFightersByWeightClass(weightClass: String!): [Fighter]
    allFighters: [Fighter]
  }
`);

const root = {
  getFighterByName: ({ name }) => {
    return fighters.find((f) => f.name.toLowerCase() === name.toLowerCase());
  },
  getFightersByWeightClass: ({ weightClass }) => {
    return fighters.filter(
      (f) => f.weightClass.toLowerCase() === weightClass.toLowerCase()
    );
  },
  allFighters: () => fighters,
};

app.use(
  "/graphql",
  graphqlHTTP({
    schema,
    rootValue: root,
    graphiql: true,
  })
);

app.listen(4000, () => {
  console.log("GraphQL API running at http://localhost:4000/graphql");
});
