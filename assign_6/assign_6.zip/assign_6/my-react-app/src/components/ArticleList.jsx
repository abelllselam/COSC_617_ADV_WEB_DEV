import React from "react";
import { ArticleItem } from "./ArticleItem";

export function ArticleList({ articles }) {
  return (
    <ul style={{ listStyle: "none", padding: 0 }}>
      {articles.map((article) => (
        <ArticleItem key={article.id} article={article} />
      ))}
    </ul>
  );
}
