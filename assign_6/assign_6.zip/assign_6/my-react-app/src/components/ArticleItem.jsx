import React from "react";

export function ArticleItem({ article }) {
  const thumbUrl = article.thumbnail.location + article.thumbnail.images.small;
  const { author, comment_count, title, url } = article;

  return (
    <li
      style={{
        marginBottom: "1.5rem",
        borderBottom: "1px solid #ccc",
        paddingBottom: "1rem",
      }}
    >
      {/* Thumbnail */}
      <a href={url} target="_blank" rel="noopener noreferrer">
        <img
          src={thumbUrl}
          alt={title}
          style={{ maxWidth: "100%", display: "block" }}
        />
      </a>

      {/* Title */}
      <h2 style={{ margin: "0.5rem 0" }}>
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          style={{ textDecoration: "none", color: "#0366d6" }}
        >
          {title}
        </a>
      </h2>

      {/* Author & Avatar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          marginBottom: "0.5rem",
        }}
      >
        <img
          src={author.avatar}
          alt={author.name}
          style={{
            width: 32,
            height: 32,
            borderRadius: "50%",
            marginRight: "0.5rem",
          }}
        />
        <span>{author.name}</span>
      </div>

      {/* Comments */}
      <div>
        <strong>Comments:</strong> {comment_count}
      </div>
    </li>
  );
}
