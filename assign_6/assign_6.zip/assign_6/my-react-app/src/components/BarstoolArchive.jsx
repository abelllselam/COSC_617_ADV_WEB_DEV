import React, { useState, useEffect } from "react";
import axios from "axios";
import { ArticleList } from "./ArticleList";

export function BarstoolArchive() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("https://www.jalirani.com/files/barstool.json")
      .then((res) => {
        setArticles(res.data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <p>Loading articles...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return <ArticleList articles={articles} />;
}
