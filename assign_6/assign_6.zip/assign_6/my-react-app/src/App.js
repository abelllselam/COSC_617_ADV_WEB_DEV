import React from "react";
import { BarstoolArchive } from "./components/BarstoolArchive";

export default function App() {
  return (
    <div>
      <h1>Barstool Throwbacks</h1>
      <BarstoolArchive />
    </div>
  );
}
